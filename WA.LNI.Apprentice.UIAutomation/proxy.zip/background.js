﻿var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "lni-swg.watech.wa.gov",
            port: parseInt(433)
        },
        bypassList: ["arts.dev.wads.wa.gov/#/"]
    }
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function () { });

function callbackFn(details) {
    return {
        authCredentials: {
            username: "LNI\CHNG235",
            password: "8897258400@nC"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        { urls: ["<all_urls>"] },
        ['blocking']
);